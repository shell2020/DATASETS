imp = IJ.openImage("http://imagej.nih.gov/ij/images/blobs.gif");
imp.show();
imp2 = IJ.openImage("http://imagej.nih.gov/ij/images/blobs.gif");
imp2.show();