imp = IJ.openImage("http://imagej.nih.gov/ij/images/blobs.gif");
imp.show();